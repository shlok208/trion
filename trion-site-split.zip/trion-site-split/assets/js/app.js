(function(){
  // ---- Mega-menu (click toggle, works for touch + mouse; hover still works via CSS) ----
  var servicesItem = document.getElementById('servicesNavItem');
  var servicesTrigger = document.getElementById('servicesTrigger');
  servicesTrigger.addEventListener('click', function(e){
    e.stopPropagation();
    var isOpen = servicesItem.classList.toggle('open');
    servicesTrigger.setAttribute('aria-expanded', isOpen ? 'true':'false');
  });
  document.addEventListener('click', function(e){
    if(!servicesItem.contains(e.target)){ servicesItem.classList.remove('open'); servicesTrigger.setAttribute('aria-expanded','false'); }
  });

  var navToggle = document.getElementById('navToggle');
  var navLinks = document.getElementById('navLinks');
  navToggle.addEventListener('click', function(){
    var showing = navLinks.style.display === 'flex';
    navLinks.style.display = showing ? 'none' : 'flex';
    navLinks.style.cssText += showing ? '' : 'position:absolute;top:100%;left:0;right:0;background:#08080a;flex-direction:column;padding:20px 40px;border-bottom:1px solid rgba(245,166,35,0.15);gap:18px;';
  });

  // ---- Testimonials marquee: duplicate track for seamless loop ----
  var tTrack = document.getElementById('tTrack');
  tTrack.innerHTML += tTrack.innerHTML;

  // ---- Method section: scroll-scrubbed frame sequence + percentage + phase highlight ----
  var section = document.getElementById('method');
  var canvas = document.getElementById('methodCanvas');
  var ctx = canvas.getContext('2d');
  var pctEl = document.getElementById('methodPct');
  var railItems = document.querySelectorAll('#phaseRail li');
  var phaseBlocks = document.querySelectorAll('.phase-block');
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var sources = window.__TRION_FRAMES__ || [];
  var images = [];
  var currentIndex = -1;
  var currentPhase = -1;
  var dpr = Math.min(window.devicePixelRatio || 1, 2);

  function sizeCanvas(){
    var rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
  }

  function drawFrame(idx){
    var img = images[idx];
    if(!img || !img.complete || img.naturalWidth === 0) return;
    var cw = canvas.width, ch = canvas.height;
    var iw = img.naturalWidth, ih = img.naturalHeight;
    var scale = Math.min(cw / iw, ch / ih);
    var dw = iw * scale, dh = ih * scale;
    var dx = (cw - dw) / 2, dy = (ch - dh) / 2;
    ctx.clearRect(0,0,cw,ch);
    ctx.drawImage(img, dx, dy, dw, dh);
    currentIndex = idx;
  }

  function setPhase(idx){
    currentPhase = idx;
    railItems.forEach(function(li,i){ li.classList.toggle('active', i===idx); });
    phaseBlocks.forEach(function(pb){ pb.classList.toggle('active', parseInt(pb.dataset.phase,10)===idx); });
  }

  var ticking = false;
  function updateScrub(){
    ticking = false;
    if(!images.length) return;
    var rect = section.getBoundingClientRect();
    var scrollable = rect.height - window.innerHeight;
    var progress = scrollable > 0 ? (-rect.top) / scrollable : 0;
    progress = Math.min(1, Math.max(0, progress));

    var idx = Math.round(progress * (images.length - 1));
    if(idx !== currentIndex) drawFrame(idx);

    pctEl.textContent = String(Math.round(progress*100)).padStart(3,'0') + '%';

    var phaseIdx = Math.min(4, Math.floor(progress * 5));
    if(phaseIdx !== currentPhase) setPhase(phaseIdx);
  }

  function onScroll(){
    if(!ticking){ window.requestAnimationFrame(updateScrub); ticking = true; }
  }

  function preload(){
    sources.forEach(function(src,i){
      var img = new Image();
      img.onload = function(){ if(i===0){ sizeCanvas(); drawFrame(0); } };
      images[i] = img; img.src = src;
    });
  }

  sizeCanvas();
  preload();

  if(!reduceMotion){
    window.addEventListener('scroll', onScroll, { passive:true });
    window.addEventListener('resize', function(){ sizeCanvas(); drawFrame(currentIndex<0?0:currentIndex); onScroll(); });
  } else {
    window.addEventListener('resize', function(){ sizeCanvas(); drawFrame(0); });
    setPhase(0);
  }
})();
